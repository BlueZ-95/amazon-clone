// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDuPGdl2jELmYY1D6G7DznmeIg04jJeB0g",
    authDomain: "clone-d922e.firebaseapp.com",
    databaseURL: "https://clone-d922e.firebaseio.com",
    projectId: "clone-d922e",
    storageBucket: "clone-d922e.appspot.com",
    messagingSenderId: "753130151061",
    appId: "1:753130151061:web:8cf0f7934d46dc7a518f9c",
    measurementId: "G-59DC3SCN5D"
  };