import React from "react";
import "./Home.css";

function Home() {
  return (
    <div className="home">
      <h1>Yo</h1>
    </div>
  );
}

export default Home;
